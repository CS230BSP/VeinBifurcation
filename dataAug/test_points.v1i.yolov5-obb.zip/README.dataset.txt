# test_points > 2022-11-06 8:46pm
https://universe.roboflow.com/bifurcation-labels/test_points

Provided by a Roboflow user
License: CC BY 4.0

